import { Component } from "react";

export class Skills extends Component {
    render() {
        return (
        <div className="skill">
            <ul type="none">
                <li>HTML</li>
                <li>CSS</li>
                <li>JavaScript</li>
                <li>React</li>
                <li>Node</li>
            </ul>
        </div>
        );
    }
}