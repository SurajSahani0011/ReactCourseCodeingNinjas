import { Component } from "react";
// Write this code in About.js file
export class About extends Component {
    render() {
      return (
        <div className="about">
          
          <p>
            Hi, my name is Pranav. I am a full stack web developer and I have developed serveral projects with MERN stack. I am familiar with Python and Django.
          </p>
        </div>
      );
    }
  }
