### Create a React App using props.

Objectives

- Use the data in the List component that is in the component folder to render the ListItem components.

- You need to complete the code of all the 3 components, i.e., App, List and ListItem

- In ListItem component, add back ground color of div and also add values of attributes of the elements listed in it with the help of props.

Output:
https://docs.google.com/document/d/1g_y48jN_IDZFskNKm1BOcq-LKZIG6CvCDtsccm0jp-I/edit
