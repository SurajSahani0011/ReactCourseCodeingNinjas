Your friend has created a name displayer where each character of the name is added to the UI after every 0.5 seconds. Now you both decided to collaborate on this project, and you are expected to add the following functionality -

- create a button that starts and stops the printing of characters.

Expected Output -
<img src="https://res.cloudinary.com/dl26pbek4/image/upload/v1675745669/cn-gifs/typewriter-effect_tcw0os.gif" />
